public class boxweight extends box {
    int weight;

    // Constructor that takes all parameters
    public boxweight(int l, int h, int w, int weight) {
        super(l, h, w); // must be the first statement
        this.weight = weight;
    }
    public boxweight(){
        super();
        weight=-1;
    }
    public boxweight(boxweight other){
        super(other.l,other.h,other.w);
        other.weight=this.weight;

    }
}
