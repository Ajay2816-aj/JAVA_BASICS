import java.security.spec.RSAOtherPrimeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class skillrack38dt {
    public static int[] alter(int[] nums) {
        List<Integer> even = new ArrayList<>();
        List<Integer> odd = new ArrayList<>();
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] % 2 == 0) {
                even.add(nums[i]);
            } else {
                odd.add(nums[i]);
            }

        }
        int n = nums.length;
        int[] result = new int[n];
        int ei = 0;
        int oi = 0;
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                result[i] = odd.get(oi);
                oi++;
            } else {
                result[i] = even.get(ei);
                ei++;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int[] nums = new int[a];
        for (int i = 0; i < a; i++) {
            nums[i] = sc.nextInt();

        }
        int[] result = alter(nums);
        for (int num : result) {
            System.out.print(num + " ");
        }
    }
}