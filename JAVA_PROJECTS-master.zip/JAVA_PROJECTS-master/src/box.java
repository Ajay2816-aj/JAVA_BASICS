public class box {
    int l;
    int h;
    int w;
    public box(int l,int h,int w){
        this.l=l;
        this.h=h;
        this.w=w;
    }
    public box(){
        this.l=-1;
        this.h=-1;
        this.w=-1;
    }
    public box(box other){
        this.l=other.l;
        this.h=other.h;
        this.w=other.w;
    }
}
