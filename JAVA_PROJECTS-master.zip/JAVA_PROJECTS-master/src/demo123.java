public class demo123 {
    public static void main(String[] args) {
        human kunal=new human(9,"hi");
        human ram=new human(10,"hello");
        System.out.println(human.population);
    }
}
