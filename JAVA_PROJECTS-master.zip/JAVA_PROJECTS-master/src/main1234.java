public class main1234 {
    public static void main(String[] args) {
        int a=5;
        int b=0;
        try{
            int c=a/b;
        }catch (ArithmeticException q){
            System.out.println(q.getMessage());
        }
    }
}
