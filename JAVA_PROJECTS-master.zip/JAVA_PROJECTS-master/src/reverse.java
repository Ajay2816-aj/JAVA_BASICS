import java.util.Arrays;

public class reverse {
    public static void main(String[] args) {
        int[]  array={2,3,4,5,6,7};
        reversearr(array);
        System.out.println(Arrays.toString(array));

    }
    static void swap(int[] arr,int a,int b){

    int t=arr[a];
    arr[a]=arr[b];
    arr[b]=t;
    }
    static void reversearr(int[]arr){
        int s=0;
        int e=arr.length-1;
        while(s<e){
        swap(arr,s,e);
        s++;
        e--;
    }
    }
}
