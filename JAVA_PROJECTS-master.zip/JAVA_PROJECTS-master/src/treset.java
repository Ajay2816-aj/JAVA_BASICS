import java.util.Set;
import java.util.TreeSet;

public class treset {
    public static void main(String[] args) {
        Set<String> a=new TreeSet<>();
        a.add("bananna");
        a.add("apple");
        System.out.println(a);
        String b=String.join(",",a);
        System.out.println(b);
        for(String ab:a){
            System.out.println(ab);
        }
    }
}
