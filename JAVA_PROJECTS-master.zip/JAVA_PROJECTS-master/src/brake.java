public interface brake {
    void brake();
}
