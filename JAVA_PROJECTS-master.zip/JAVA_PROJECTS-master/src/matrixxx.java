import java.util.Scanner;

public class matrixxx {
    public static void main(String[] args) {


                Scanner sc = new Scanner(System.in);

                // Read the number of rows and columns
                int R = sc.nextInt();
                int C = sc.nextInt();

                // Declare the matrix
                int[][] matrix = new int[R][C];

                // Read matrix values (all assumed to be two-digit numbers)
                for (int i = 0; i < R; i++) {
                    for (int j = 0; j < C; j++) {
                        matrix[i][j] = sc.nextInt();
                    }
                }

                // Print the matrix (optional)
                System.out.println("Matrix:");
                for (int i = 0; i < R; i++) {
                    for (int j = 0; j < C; j++) {
                        System.out.print(matrix[i][j] + " ");
                    }
                    System.out.println();
                }
            }
        }


