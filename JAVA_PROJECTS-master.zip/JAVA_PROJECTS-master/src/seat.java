
    import java.util.*;

    public class seat {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);

            // Input size
            System.out.print("Enter number of people: ");
            int n = sc.nextInt();

            // Input desired seats
            int[] desired = new int[n];
            System.out.print("Enter desired seats: ");
            for (int i = 0; i < n; i++) {
                desired[i] = sc.nextInt();
            }

            int[] result = assignSeats(desired, n);
            System.out.println("Assigned seats: " + Arrays.toString(result));
        }

        public static int[] assignSeats(int[] desired, int n) {
            boolean[] occupied = new boolean[n + 1]; // 1-based indexing
            int[] result = new int[n];

            for (int i = 0; i < n; i++) {
                int want = desired[i];

                // Try desired seat first
                if (!occupied[want]) {
                    result[i] = want;
                    occupied[want] = true;
                    continue;
                }

                // Search nearest unoccupied seat to left/right
                int dist = 1;
                while (true) {
                    boolean assigned = false;

                    // Check left
                    if (want - dist >= 1 && !occupied[want - dist]) {
                        result[i] = want - dist;
                        occupied[want - dist] = true;
                        assigned = true;
                        break;
                    }

                    // Check right
                    if (want + dist <= n && !occupied[want + dist]) {
                        result[i] = want + dist;
                        occupied[want + dist] = true;
                        assigned = true;
                        break;
                    }

                    dist++;

                    // If no seats found after scanning all
                    if (want - dist < 1 && want + dist > n) {
                        result[i] = 0; // or throw error if needed
                        break;
                    }
                }
            }

            return result;
        }
    }


