public class maininterfaces {
    public static void main(String[] args) {
        car a=new car();
        a.start();
        a.stop();
        a.brake();
    }
}
