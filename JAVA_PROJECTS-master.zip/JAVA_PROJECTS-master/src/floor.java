public class floor {
    public static void main(String[] args) {
        int[] a={-18,-12,-4,0,2,3,4,15,16,18,22,45,89};
        int target=5;
        int ans= ceiling(a,target);
        System.out.println(ans);
    }
    static int ceiling(int[] a, int target){

        if(target>a[a.length-1]){
            return -1;
        }
        int start=0;
        int end=a.length-1;


        while(start<=end){
            int mid=(start+end)/2;
            if(a[mid]==target){
                return mid;
            }
            if(a[mid]<target){
                start=mid+1;
            }
            else{
                end=mid-1;
            }
        }
        return a[end];
    }
}




