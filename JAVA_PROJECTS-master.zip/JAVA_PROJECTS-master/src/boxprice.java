public class boxprice extends boxweight{
    int cost;
    public boxprice(int l,int h,int w,int weight,int cost ) {
        super(l, h, w, weight);
        this.cost = cost;
    }
        public boxprice(){
            super();
            this.cost=-1;
        }

}
