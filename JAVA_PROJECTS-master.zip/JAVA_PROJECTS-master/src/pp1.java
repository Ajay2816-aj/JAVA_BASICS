public class pp1 {
    public static void main(String[] args) {

    }
}
