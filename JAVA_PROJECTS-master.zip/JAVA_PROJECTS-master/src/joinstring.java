import java.util.List;

public class joinstring {
    public static void main(String[] args) {
        List<String>a=List.of("apple","Mango");
        System.out.print(String.join("+",a));
        System.out.println(String.join("-","Mango","apple","orange"));
    }
}
