import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
       // sum();
        Scanner sc = new Scanner(System.in);
        System.out.print("please enter a name:");
    }

    static void sum() {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int sum = a + b;
        System.out.println("the sum is  =" + sum);
    }
    static String greet(String name) {
        return "Hello " + name + "!";
    }
}