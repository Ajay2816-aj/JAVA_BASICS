abstract class parent {

        abstract void carrer();
        abstract void partner();

}
