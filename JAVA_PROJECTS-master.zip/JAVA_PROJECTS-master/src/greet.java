public class greet {
    public static void main(String[] args) {

    }
    public static void greeting(){
        System.out.println("it's amazing");
    }
}
