import java.util.Scanner;



public class stringcount11 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String a=sc.nextLine();
        String[]ab=a.split(" ");
        int c=ab.length;
        System.out.println(c);

    }
}
