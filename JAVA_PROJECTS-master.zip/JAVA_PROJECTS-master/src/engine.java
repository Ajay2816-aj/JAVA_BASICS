public interface engine {
     void start();
     void stop();
}
