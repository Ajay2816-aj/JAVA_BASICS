public class car implements engine,brake{
    @Override
    public void start() {
        System.out.println("i am going to start");
    }

    @Override
    public void stop() {
        System.out.println("i am going to stop");
    }

    @Override
    public void brake() {
        System.out.println("i am going to apply brake");
    }
}
