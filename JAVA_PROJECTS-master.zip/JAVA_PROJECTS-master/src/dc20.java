import java.util.HashMap;

public class dc20 {
    public static int  count(int N,int[] arr){
        HashMap<Integer,Integer> a=new HashMap<>();
        for(int num:arr){
            a.put(num,a.getOrDefault(num,0)+1);

        }
        int c=0;
        for(int nums:a.values()){
            c+=nums/2;
        }
        return c;
    }

    public static void main(String[] args) {
        int N = 9;
        int[] arr = {15, 25, 25, 15, 15, 35, 45, 15, 25};
        System.out.println(count(N, arr));
    }
}
