import java.util.*;

public class vir {
    public static int[] replaceZeros(int[] arr) {
        int n = arr.length;
        int[] res = Arrays.copyOf(arr, n);

        for (int i = 0; i < n; i++) {
            if (arr[i] == 0) {
                int closestIndex = -1;
                int minDistance = Integer.MAX_VALUE;

                for (int j = 0; j < n; j++) {
                    if (arr[j] != 0 && Math.abs(arr[j]) > 0) {
                        if (Math.abs(arr[j]) > 0) {
                            int distance = Math.abs(j - i);
                            if (distance < minDistance) {
                                minDistance = distance;
                                closestIndex = j;
                            }
                        }
                    }
                }

                if (closestIndex != -1) {
                    res[i] = arr[closestIndex];
                }
            }
        }

        return res;
    }

    public static void main(String[] args) {
        int[] arr = {0, 4, 0, 5, -6};
        int[] result = replaceZeros(arr);
        System.out.println(Arrays.toString(result));
    }
}
