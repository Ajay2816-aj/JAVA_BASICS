import java.util.Arrays;

public class maxin2darr {
    public static void main(String[] args) {
        int[][] a = {{1,3},{7,8,9},{10,11,13}};
        int maxvalue=max2d(a);
        System.out.println(maxvalue);



    }
    static int max2d(int[][] num) {
        int max=Integer.MIN_VALUE;
        for(int i=0;i<num.length;i++) {
            for(int j=0;j<num[i].length;j++) {
                if(num[i][j]>max) {
                    max=num[i][j];

                }
            }

        }
        return  max;


    }
}
