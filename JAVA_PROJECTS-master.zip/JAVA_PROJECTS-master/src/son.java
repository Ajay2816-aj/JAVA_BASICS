public class son extends parent{
    void carrer(){
        System.out.println("i want to be a coder");
    }
     void partner(){
         System.out.println("Riya");
     }
}
