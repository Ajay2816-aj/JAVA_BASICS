import java.util.Arrays; // Import the Arrays class

class BinarySearch {
    public static void main(String[] args) {
        int[][] arr = {
                {10, 20, 30, 40},
                {15, 25, 35, 45},
                {28, 29, 37, 49},
                {33, 34, 38, 50}
        };
        int[] result = search(arr, 37);
        System.out.println(Arrays.toString(result)); // Use Arrays.toString() correctly
    }

    static int[] search(int[][] matrix, int target) {
        int r = 0;
        int c = matrix.length - 1; // Fix: Use matrix[0].length - 1 for last column index

        while (r < matrix.length && c >= 0) {
            if (matrix[r][c] == target) {
                return new int[]{r, c}; // Found target
            }
            if (matrix[r][c] < target) {
                r++; // Move down
            } else {
                c--; // Move left
            }
        }
        return new int[]{-1, -1}; // Target not found
    }
}

