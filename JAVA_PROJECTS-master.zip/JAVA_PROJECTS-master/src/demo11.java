public class demo11 {
    public static void main(String[] args) {
        System.out.println("hi");
        greet.greeting();
    }
}
