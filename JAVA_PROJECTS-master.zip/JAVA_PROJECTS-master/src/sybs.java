import java.util.Scanner;

public class sybs {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String a=sc.next();
        String b=a.substring(1,a.length()-1);
        System.out.println(b);

        String c=sc.next();
        StringBuilder d=new StringBuilder(c);
        d.deleteCharAt(0);
        d.deleteCharAt(d.length()-1);
        System.out.println(d.toString());


    }
}
