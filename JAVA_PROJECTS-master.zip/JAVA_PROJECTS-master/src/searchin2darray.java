import java.util.Arrays;

public class searchin2darray {
    public static void main(String[] args) {
        int[][] a = {{1,3},{7,8,9},{10,11,13}};
        int target=9;
        int [] b=Search(a,target);
        System.out.println(Arrays.toString(b));
    }
     static int[] Search(int[][] num, int target) {
        for(int i=0;i<num.length;i++) {
            for(int j=0;j<num[i].length;j++) {
                if(num[i][j]==target) {
                    return new int[]{i,j};

                }
            }

        }
        return new int[]{-1,-1};


     }
}
