public class binary {
    public static void main(String[] args) {
        int[] a={-18,-12,-4,0,2,3,4,15,16,18,22,45,89};
        int target=22;
        int ans=binarysearch(a,target);
        System.out.println(ans);
    }
     static int binarysearch(int[] a,int target){
        int start=0;
        int end=a.length-1;
        while(start<=end){
            int mid=(start+end)/2;
            if(a[mid]==target){
                return mid;
            }
            if(a[mid]<target){
                start=mid+1;
            }
            else{
                end=mid-1;
            }
        }
        return -1;
     }
}
