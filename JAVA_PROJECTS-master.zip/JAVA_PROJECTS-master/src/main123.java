public class main123 {
    public static void main(String[] args) {
        boxweight a=new boxweight(2,3,4,5);
        System.out.println(a.l);
        boxweight b=new boxweight(a);
        System.out.println(b.l);
        boxprice c=new boxprice(4,5,6,7,8);
        System.out.println(c.l);
        boxprice d=new boxprice();
        System.out.println(d.cost);
    }
}
