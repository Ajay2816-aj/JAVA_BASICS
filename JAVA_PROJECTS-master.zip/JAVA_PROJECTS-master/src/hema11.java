import java.security.spec.RSAOtherPrimeInfo;

public class hema11 {
    public static void main(String[] args) {
        int[] a={1,2,3,4,5};
        for(int i=0;i<a.length;i++){
            System.out.println(a[i]);
        }
        int[] tem=new int[a.length];
        for(int i=0;i<a.length;i++){
            tem[i]=a[i];
        }
        System.out.println(tem);
    }
}
