import java.util.Scanner;

public class unaskar {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int[] b=new int[a];
        for(int i=0;i<a;i++){
            b[i]=sc.nextInt();
        }
        for(int i=0;i<a;i++){
            if(b[i]>0){
                int j=i;
                while(j>0 && b[j-1]<0){
                    int temp=b[j-1];
                    b[j-1]=b[j];
                    b[j]=temp;
                    j--;
                }
            }
        }
        for(int i=0;i<a;i++){
            System.out.print(b[i]+" ");
        }
    }
}
