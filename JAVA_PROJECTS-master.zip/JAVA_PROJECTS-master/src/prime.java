
import java.util.Scanner;

public class prime {
    public static void main(String[] args) {
    Scanner in =new Scanner(System.in);
    //int n=in.nextInt();
    //boolean a=isprime(n);
    //System.out.println(a);
//    int w=in.nextInt();
//    boolean b=arm(w);
//    System.out.println(b);
      for(int i=100;i<=999;i++){
          if(arm(i)){
              System.out.println(i);
          }
      }


}
//static boolean isprime(int b) {
//    if (b <= 1) {
//        return false;
//    }
//    int c = 2;
//    while (c * c <= b) {
//        if (b % c == 0) {
//            return false;
//        }
//        c++;
//    }
//    return c * c >= b;
//}
static boolean arm(int a){
        int o=a;
        int r=0;
        int s=0;
        while(a>0){
            r=a%10;
            s=s+r*r*r;
            a=a/10;
        }
        if(s==o){
            return true;
        }
        return false;
}
}
