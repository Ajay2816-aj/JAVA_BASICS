public class classes1 {
    public static void main(String[] args) {
        student student1 = new student();
        student1.rollno = 1;
        student1.name = "ram";
        System.out.println(student1); // Will now print in a readable format
    }


    }

class student {
    int rollno;
    String name;
    double marks;


}
