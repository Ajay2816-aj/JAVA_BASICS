
    import java.util.Scanner;

    public class interlace {

        public static void main(String[] args) {
           Scanner sc=new Scanner(System.in);
           int a=sc.nextInt();
           int b=sc.nextInt();
           int i=a;
           int j=b;
           while(i<=b || j>=a){
               if(i<=b){
                   if(i%2==1){
                       System.out.print(i+" ");
                   }
                   i++;
               }
               if(j>=a){
                   if(j%2==0){
                       System.out.print(j+" ");
                   }
                   j--;
               }
           }
        }
    }

