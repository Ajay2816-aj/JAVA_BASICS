public class daughter extends parent{
    void carrer(){
        System.out.println("i want to be doctor");
    }
    void partner(){
        System.out.println("krishna");
    }
}
