public class abstractmain {
    public static void main(String[] args) {
        son a=new son();
        a.carrer();
        daughter b=new daughter();
        b.carrer();


    }
}
